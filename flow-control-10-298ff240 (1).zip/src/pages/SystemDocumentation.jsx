
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ArrowLeft, Download, Clipboard, Plus, Edit, Trash2, Loader2, BookOpen, Palette, Route, CheckCircle, Server, Code, Sparkles, Activity, AlertTriangle, Zap, Smartphone } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { DocumentationNote } from '@/api/entities';

// --- Full Conversation History Text (Simulated) ---
const fullConversationHistoryText = `
User: [התחלת הפרויקט, הנחיות ראשוניות...]

Base44: ...

User: the following errors happened in the app: <error title="error trying to call function: /getNewDeliveryPageData" ...>

Base44: אני רואה שיש בעיה בקריאה לפונקציה... אני אתקן את דף NewDelivery כך שיעבוד ללא תלות בפונקציית השרת...
<action_group>...</action_group>

User: the following errors happened in the app: <error title="in InventoryReplenishmentPage: TypeError: Cannot read properties of undefined (reading 'size')" ...>

Base44: אני רואה שהבעיה עדיין קיימת בדף InventoryReplenishment. הבעיה היא שהשתמשתי ב-useState במקום להגדיר את selectedItems כ-Set באופן נכון. אני אתקן את זה כעת...
<action_group>...</action_group>

User: בדוק אחרונה באיזה תוכנית היינו ומה נדרש להשלים?

Base44: נכון, בוא נסכם איפה אנחנו עומדים... המטרה העיקרית שלך הייתה לשפר את יציבות וביצועי המערכת... מה שנותר הוא Cache ב-Frontend...

User: השלם מה שנדרש גם דיברנו על מחיקת התראות מיותרות וגם אמרנו שבמקום התראות קופצות יהיה מקום יעודי...

Base44: מעולה... אצור NotificationCenter.jsx, אשנה את useToast...
<action_group>...</action_group>

User: [צילום מסך שגיאה בדף ניהול אצוות] ...חזרה מדף עריכה גורמת לשגיאת מזהה...

Base44: הבעיה היא שהדף מחפש פרמטר id שלא קיים... אתקן...
<action_group>...</action_group>
`;

// --- System Specification Text (Updated) ---
const systemSpecificationText = (
  <div className="prose prose-sm max-w-none" dir="rtl">
    <h2 className="text-xl font-bold">אפיון מערכת ניהול מלאי ריאגנטים (Flow Control) - כללי</h2>
    <p>מסמך זה מאפיין את המערכת, תהליכי העבודה המרכזיים, מסעות המשתמש, עקרונות ה-UX, והבדיקות לכל מודול.</p>

    <h3 className="text-lg font-semibold mt-4">עקרונות מנחים</h3>
    <ul>
      <li><strong>מקור אמת יחיד:</strong> עדכון מלאי רק דרך טרנזקציות.</li>
      <li><strong>הפרדת דאגות:</strong> לוגיקה בשרת, UI מציג.</li>
      <li><strong>UX:</strong> אינטואיטיבי, מונע טעויות, משוב ברור.</li>
      <li><strong>ביצועים:</strong> Cache, פונקציות שרת, טעינה מדורגת.</li>
    </ul>

    <h3 className="text-lg font-semibold mt-4">מודולים מרכזיים</h3>

    <h4>דשבורד</h4>
    <p>תמונת מצב מהירה, קיצורי דרך, והתראות.</p>

    <h4>ניהול דרישות רכש</h4>
    <p>סינון לפי סטטוס, ספק וחיפוש; עדכונים בהתאם לסטטוס.</p>

    <h4>ניהול אצוות ותפוגות</h4>
    <p>טיפול באצוות פגות/עומדות לפוג, לוג פעולות, קישור COA.</p>

    <h4>קליטת משלוח</h4>
    <p>קישור להזמנה/משיכה, יצירת אצוות, טרנזקציות מלאי, ולידציה.</p>
    <p>קליטת משלוח, ניהול הזמנות, ספירת מלאי, ניהול אצוות, דוחות ועוד.</p>
  </div>
);

// --- Design System Document ---
const designSystemDocument = (
    <div className="prose prose-lg max-w-none" dir="rtl">
        <h2 className="text-2xl font-bold flex items-center"><Palette className="ml-3 h-7 w-7 text-blue-600" />מערכת העיצוב (Design System) - Flow Control</h2>
        <p>מסמך זה מגדיר את הסטנדרטים והשפה העיצובית של המערכת. כל פיתוח חדש וכל שדרוג עיצובי יתבססו על עקרונות אלו כדי להבטיח חווית משתמש אחידה, נגישה ויעילה.</p>

        <h3 className="text-xl font-semibold mt-6">עקרונות כלליים</h3>
        <ul>
            <li><strong>בהירות ופשטות:</strong> הימנעות מעומס ויזואלי. כל רכיב צריך להיות ברור בתפקודו.</li>
            <li><strong>עקביות:</strong> שימוש חוזר ברכיבים ובדפוסים זהים לביצוע פעולות דומות.</li>
            <li><strong>שפה מוכוונת-פעולה:</strong> שימוש בטקסטים שמניעים את המשתמש לפעולה ומבהירים לו מה נדרש ממנו.</li>
            <li><strong>נגישות:</strong> תמיכה מלאה במקלדת, ניגודיות גבוהה ותאימות ל-RTL.</li>
        </ul>

        <h3 className="text-xl font-semibold mt-8">1. דפים (Pages)</h3>
        <h4>פריסה כללית (Layout)</h4>
        <ul className="list-disc pl-5">
            <li><strong>כותרת ראשית:</strong> תמיד בראש העמוד, גדולה ובולטת (`text-2xl font-bold`).</li>
            <li><strong>כפתורי ניווט/פעולות משניות:</strong> מתחת לכותרת הראשית (למשל: "חזור", "רשימת משלוחים"), בעיצוב עדין יותר (outline/ghost).</li>
            <li><strong>כפתור פעולה ראשי:</strong> יוצב בתחתית העמוד (ובסרגל צף במובייל) בצבע ירוק בולט.</li>
        </ul>

        <h3 className="text-xl font-semibold mt-8">2. כרטיסים (Cards)</h3>
        <h4>מבנה ועיצוב</h4>
        <ul className="list-disc pl-5">
            <li><strong>פינות:</strong> מעוגלות (`rounded-xl` או `rounded-lg`).</li>
            <li><strong>רקע:</strong> רקע בהיר עם שקיפות קלה (`bg-white/80`, `bg-blue-50/80`) ואפקט טשטוש (`backdrop-blur-sm`).</li>
            <li><strong>גבולות וצל:</strong> גבול דק ועדין (`border border-gray-200`) וצל רך (`shadow-md` או `shadow-lg`).</li>
            <li><strong>ריווח פנימי:</strong> ריווח נדיב (`p-4` או `p-6`) כדי לאפשר לתוכן "לנשום".</li>
        </ul>

        <h3 className="text-xl font-semibold mt-8">3. טבלאות (Tables)</h3>
        <h4>אינטראקטיביות ועיצוב</h4>
        <ul className="list-disc pl-5">
            <li><strong>קישור במקום פעולות:</strong> הנתון המרכזי בשורה (למשל, "שם הפריט" או "מספר הזמנה") ישמש כקישור הראשי לפתיחת פרטים או עריכה. הקישור יהיה בצבע כחול בולט ועם קו תחתון בריחוף.</li>
            <li><strong>עמודת "פעולות":</strong> יש להימנע ממנה ככל הניתן. במקרים חריגים, יש להשתמש באייקונים קטנים (כמו מחיקה) ולא בכפתורים גדולים.</li>
            <li><strong>קריאות:</strong> שימוש בריווח ברור בין שורות, כותרות עמודה בולטות ורקע עדין בריחוף על שורה (`hover:bg-gray-50`).</li>
        </ul>

        <h3 className="text-xl font-semibold mt-8">4. שפה וטקסטים (Language & Copy)</h3>
        <h4>שפה מוכוונת-פעולה (Action-Oriented)</h4>
        <p>במיוחד ב"מרכז הבקרה" ובהתראות, יש להשתמש בשפה המנחה את המשתמש לפעולה.</p>
        <ul className="list-disc pl-5">
            <li><strong>דוגמה טובה:</strong> "ישנם 3 מוצרים שפג תוקפם. <strong>לחץ כאן לטיפול</strong>."</li>
            <li><strong>דוגמה טובה:</strong> "הגיע הזמן לבצע ספירת מלאי חודשית. <strong>לחץ כאן להתחלת הספירה</strong>."</li>
            <li><strong>דוגמה לא טובה:</strong> "סטטוס ספירת מלאי: נדרש".</li>
        </ul>
    </div>
);

// --- Implementation Strategy Document ---
const implementationStrategyDocument = (
    <div className="prose prose-lg max-w-none" dir="rtl">
        <h2 className="text-2xl font-bold flex items-center"><Route className="ml-3 h-7 w-7 text-green-600" />אסטרטגיית יישום העיצוב המחודש</h2>
        <p>מסמך זה מתאר את תהליך העבודה המוסכם ליישום מערכת העיצוב החדשה בכל רחבי האפליקציה, באופן הדרגתי ומבוקר.</p>

        <h3 className="text-xl font-semibold mt-6">מטרה</h3>
        <p>להבטיח שכל מסכי המערכת יעודכנו בהתאם לסטנדרטים שהוגדרו ב"מערכת העיצוב", תוך שמירה על יציבות ופונקציונליות מלאה לאורך כל התהליך.</p>

        <h3 className="text-xl font-semibold mt-8">תהליך העבודה האיטרטיבי</h3>
        <p>התהליך יבוצע באופן מחזורי עבור כל מסך או קבוצת מסכים במערכת:</p>
        <ol className="list-decimal pl-6 space-y-3">
            <li>
                <strong>שלב 1: בחירת מסך וניתוח מצב קיים</strong>
                <p>אני (המשתמש) אבחר מסך ואשלח לך צילום מסך של המצב הנוכחי שלו.</p>
            </li>
            <li>
                <strong>שלב 2: תכנון ואיפיון מחדש</strong>
                <p>אתה (Base44) תנתח את המסך בהתאם ל"מערכת העיצוב" ותציע תוכנית פעולה מפורטת לעיצובו מחדש. התוכנית תכלול שינויים בפריסה, ברכיבים, בצבעים ובטקסטים.</p>
            </li>
            <li>
                <strong>שלב 3: תיעוד ואישור</strong>
                <p>התוכנית שהצעת תתועד כאן, תחת סעיף "תוכניות יישום למסכים". לאחר שאאשר את התוכנית, נתקדם לשלב הביצוע.</p>
            </li>
            <li>
                <strong>שלב 4: ביצוע ויישום</strong>
                <p>אתה תבצע את השינויים הנדרשים בקוד ותציג את התוצאה.</p>
            </li>
            <li>
                <strong>שלב 5: בדיקה ומעבר למסך הבא</strong>
                <p>לאחר בדיקה ואישור שלי שהמסך עומד בסטנדרטים, נוכל לעבור למסך הבא בתור.</p>
            </li>
        </ol>

        <h3 className="text-xl font-semibold mt-8">נקודת התחלה: מרכז הבקרה</h3>
        <p>תהליך העיצוב מחדש יחל במסך הראשי של המערכת - <strong>"מרכז הבקרה"</strong> (הדשבורד הנוכחי).</p>
    </div>
);


export default function SystemDocumentation() {
  const navigate = useNavigate();
  const { toast } = useToast();

  // Notes state
  const [notes, setNotes] = useState([]);
  const [loadingNotes, setLoadingNotes] = useState(true);
  const [showNoteDialog, setShowNoteDialog] = useState(false);
  const [editingNote, setEditingNote] = useState(null);
  const [noteFormData, setNoteFormData] = useState({ title: '', content: '' });

  const fetchNotes = useCallback(async () => {
    setLoadingNotes(true);
    try {
      const notesData = await DocumentationNote.list('-created_date');
      setNotes(Array.isArray(notesData) ? notesData : []);
    } catch (error) {
      console.error("Failed to fetch documentation notes:", error);
      toast({ title: "שגיאה בטעינת הערות", variant: "destructive" });
    } finally {
      setLoadingNotes(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchNotes();
  }, [fetchNotes]);

  const handleSaveNote = async () => {
    if (!noteFormData.content.trim()) {
      toast({ title: "תוכן ההערה לא יכול להיות ריק", variant: "destructive" });
      return;
    }
    try {
      if (editingNote) {
        await DocumentationNote.update(editingNote.id, noteFormData);
        toast({ title: "הערה עודכנה בהצלחה" });
      } else {
        await DocumentationNote.create(noteFormData);
        toast({ title: "הערה חדשה נשמרה" });
      }
      setShowNoteDialog(false);
      setEditingNote(null);
      setNoteFormData({ title: '', content: '' });
      fetchNotes();
    } catch (error) {
      console.error("Failed to save note:", error);
      toast({ title: "שגיאה בשמירת ההערה", variant: "destructive" });
    }
  };

  const handleEditNote = (note) => {
    setEditingNote(note);
    setNoteFormData({ title: note.title || '', content: note.content || '' });
    setShowNoteDialog(true);
  };

  const handleDeleteNote = async (noteId) => {
    if (confirm("האם למחוק את ההערה?")) {
      try {
        await DocumentationNote.delete(noteId);
        toast({ title: "הערה נמחקה" });
        fetchNotes();
      } catch (error) {
        console.error("Failed to delete note:", error);
        toast({ title: "שגיאה במחיקת ההערה", variant: "destructive" });
      }
    }
  };

  const handleCopyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: "הטקסט הועתק ללוח" });
    }, (err) => {
      toast({ title: "שגיאה בהעתקה", description: err.message, variant: "destructive" });
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6" dir="rtl">
      <div className="flex items-center mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="ml-4">
          <ArrowLeft className="h-5 w-5" />
        </Button>
        <h1 className="text-2xl font-bold">מסמכי מערכת</h1>
      </div>

      <Tabs defaultValue="inventory-count-validation" className="w-full">
        <TabsList className="grid w-full grid-cols-5 md:grid-cols-6 lg:grid-cols-7"> {/* Adjusted grid-cols for new tab */}
          <TabsTrigger value="inventory-count-validation" className="whitespace-nowrap"><CheckCircle className="ml-2 h-4 w-4" />בדיקת מלאי</TabsTrigger>
          <TabsTrigger value="design" className="whitespace-nowrap"><Palette className="ml-2 h-4 w-4" />מערכת עיצוב</TabsTrigger>
          <TabsTrigger value="strategy" className="whitespace-nowrap"><Route className="ml-2 h-4 w-4" />אסטרטגיית יישום</TabsTrigger>
          <TabsTrigger value="specification" className="whitespace-nowrap">אפיון מערכת</TabsTrigger>
          <TabsTrigger value="personal_notes" className="whitespace-nowrap">הערות ותיעוד</TabsTrigger>
          <TabsTrigger value="full_history" className="whitespace-nowrap">היסטוריית שיחה מלאה</TabsTrigger>
        </TabsList>

        <TabsContent value="design" className="mt-4">
            <Card>
                <CardContent className="pt-6">
                    {designSystemDocument}
                </CardContent>
            </Card>
        </TabsContent>
        
        <TabsContent value="strategy" className="mt-4">
            <Card>
                <CardContent className="pt-6">
                    {implementationStrategyDocument}
                </CardContent>
            </Card>
        </TabsContent>

        <TabsContent value="specification" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>אפיון מערכת מפורט</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[65vh] w-full p-4 border rounded-md">
                {systemSpecificationText}
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="personal_notes" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>הערות ותיעוד אישי</CardTitle>
                <Button onClick={() => { setEditingNote(null); setNoteFormData({ title: '', content: '' }); setShowNoteDialog(true); }}>
                  <Plus className="h-4 w-4 ml-2" />
                  הוסף הערה
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {loadingNotes ? (
                <div className="text-center"><Loader2 className="h-6 w-6 animate-spin" /></div>
              ) : notes.length === 0 ? (
                <p className="text-center text-gray-500 py-8">אין הערות. לחץ על "הוסף הערה" כדי להתחיל.</p>
              ) : (
                <ScrollArea className="h-[60vh] p-1">
                  <div className="space-y-4">
                    {notes.map(note => (
                      <Card key={note.id} className="bg-white">
                        <CardHeader className="pb-2">
                          <div className="flex justify-between items-start">
                            <h4 className="font-bold text-lg">{note.title}</h4>
                            <div className="flex items-center gap-1">
                              <Button variant="ghost" size="icon" onClick={() => handleEditNote(note)}><Edit className="h-4 w-4" /></Button>
                              <Button variant="ghost" size="icon" className="text-red-500" onClick={() => handleDeleteNote(note.id)}><Trash2 className="h-4 w-4" /></Button>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="whitespace-pre-wrap">{note.content}</p>
                          <p className="text-xs text-gray-400 mt-2">נוצר: {new Date(note.created_date).toLocaleString('he-IL')}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="full_history" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>היסטוריית שיחה מלאה</CardTitle>
                <Button variant="outline" onClick={() => handleCopyToClipboard(fullConversationHistoryText)}>
                  <Clipboard className="h-4 w-4 ml-2" /> העתק ללוח
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[60vh] w-full bg-gray-900 text-white p-4 rounded-md">
                <pre className="text-sm whitespace-pre-wrap font-mono">{fullConversationHistoryText}</pre>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="inventory-count-validation" className="mt-4 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-6 w-6 text-green-600" />
                בדיקת תקינות - מסך ספירת מלאי
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              
              {/* Backend Functions Validation */}
              <div>
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Server className="h-5 w-5 text-blue-600" />
                  1. בדיקת פונקציות Backend
                </h3>
                <div className="space-y-3 pr-6">
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">getInventoryCountDraftData</p>
                      <p className="text-sm text-gray-600">✅ טוענת נתונים חכמים מספירה אחרונה</p>
                      <p className="text-sm text-gray-600">✅ מזהה אצוות חדשות ממשלוחים</p>
                      <p className="text-sm text-gray-600">✅ מחזירה סיכום מפורט</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">processCompletedCount</p>
                      <p className="text-sm text-gray-600">✅ מעבד ספירה שהסתיימה</p>
                      <p className="text-sm text-gray-600">✅ מטפל באצוות אפס (consumed)</p>
                      <p className="text-sm text-gray-600">✅ יוצר InventoryTransaction מתאים</p>
                      <p className="text-sm text-gray-600">✅ מעדכן ReagentBatch</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">getInventoryCountsHistoryData</p>
                      <p className="text-sm text-gray-600">✅ מחזירה היסטוריה עם פילטרים</p>
                      <p className="text-sm text-gray-600">✅ תומכת ב-pagination</p>
                      <p className="text-sm text-gray-600">✅ תומכת במיון</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">getSingleInventoryCountDetails</p>
                      <p className="text-sm text-gray-600">✅ מחזירה פרטי ספירה בודדת</p>
                      <p className="text-sm text-gray-600">✅ כולל כל האצוות והכמויות</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Frontend Components Validation */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Code className="h-5 w-5 text-purple-600" />
                  2. בדיקת קומפוננטות Frontend
                </h3>
                <div className="space-y-3 pr-6">
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">InventoryCount.js (מסך ראשי)</p>
                      <p className="text-sm text-gray-600">✅ טוען נתונים חכמים בהצלחה</p>
                      <p className="text-sm text-gray-600">✅ כולל fallback למצב רגיל</p>
                      <p className="text-sm text-gray-600">✅ שומר טיוטה אוטומטית</p>
                      <p className="text-sm text-gray-600">✅ שולח ספירה לעיבוד</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">ReagentItem.jsx</p>
                      <p className="text-sm text-gray-600">✅ מציג אצוות חדשות עם Badge</p>
                      <p className="text-sm text-gray-600">✅ מציג כמויות מספירה אחרונה</p>
                      <p className="text-sm text-gray-600">✅ responsive למובייל</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">BatchEntry.jsx</p>
                      <p className="text-sm text-gray-600">✅ מאפשר הזנת כמויות</p>
                      <p className="text-sm text-gray-600">✅ תצוגה ברורה של כמות נוכחית</p>
                      <p className="text-sm text-gray-600">✅ הדגשת אצוות חדשות</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* UI/UX Features Validation */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-amber-600" />
                  3. בדיקת תכונות UI/UX
                </h3>
                <div className="space-y-3 pr-6">
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">פילטרים חכמים</p>
                      <p className="text-sm text-gray-600">✅ פילטר לפי ספק</p>
                      <p className="text-sm text-gray-600">✅ פילטר לפי קטגוריה</p>
                      <p className="text-sm text-gray-600">✅ חיפוש טקסט חופשי</p>
                      <p className="text-sm text-gray-600">✅ Sheet צד במובייל עם Glassmorphism</p>
                      <p className="text-sm text-gray-600">✅ מונה פילטרים פעילים</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">טאב היסטוריה</p>
                      <p className="text-sm text-gray-600">✅ תצוגת טבלה בדסקטופ</p>
                      <p className="text-sm text-gray-600">✅ תצוגת Cards במובייל</p>
                      <p className="text-sm text-gray-600">✅ פילטרים מתקדמים</p>
                      <p className="text-sm text-gray-600">✅ Pagination</p>
                      <p className="text-sm text-gray-600">✅ מיון</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">כפתורי פעולה</p>
                      <p className="text-sm text-gray-600">✅ שמירת טיוטה</p>
                      <p className="text-sm text-gray-600">✅ ייצוא ל-Excel</p>
                      <p className="text-sm text-gray-600">✅ ניקוי טיוטה</p>
                      <p className="text-sm text-gray-600">✅ שליחה לעיבוד</p>
                      <p className="text-sm text-gray-600">✅ Sticky bottom bar</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Data Flow Validation */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Activity className="h-5 w-5 text-teal-600" />
                  4. בדיקת זרימת נתונים
                </h3>
                <div className="space-y-3 pr-6">
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">תחילת ספירה</p>
                      <p className="text-sm text-gray-600">1️⃣ Frontend קורא ל-getInventoryCountDraftData()</p>
                      <p className="text-sm text-gray-600">2️⃣ Backend שולף ספירה אחרונה</p>
                      <p className="text-sm text-gray-600">3️⃣ Backend מזהה אצוות חדשות</p>
                      <p className="text-sm text-gray-600">4️⃣ Frontend מציג עם הדגשות</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">שמירת טיוטה</p>
                      <p className="text-sm text-gray-600">1️⃣ Frontend אוסף נתונים</p>
                      <p className="text-sm text-gray-600">2️⃣ שמירה ב-InventoryCountDraft</p>
                      <p className="text-sm text-gray-600">3️⃣ עדכון lastUpdate</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">סיום ספירה</p>
                      <p className="text-sm text-gray-600">1️⃣ Frontend שולח draftId</p>
                      <p className="text-sm text-gray-600">2️⃣ processCompletedCount() מעבד</p>
                      <p className="text-sm text-gray-600">3️⃣ יצירת CompletedInventoryCount</p>
                      <p className="text-sm text-gray-600">4️⃣ עדכון ReagentBatch (כולל consumed)</p>
                      <p className="text-sm text-gray-600">5️⃣ יצירת InventoryTransaction</p>
                      <p className="text-sm text-gray-600">6️⃣ הרצת runSummaryUpdates()</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Edge Cases Validation */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-orange-600" />
                  5. בדיקת מקרי קצה
                </h3>
                <div className="space-y-3 pr-6">
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">אין ספירה קודמת</p>
                      <p className="text-sm text-gray-600">✅ המערכת מתחילה ספירה חדשה</p>
                      <p className="text-sm text-gray-600">✅ כל האצוות מופיעות עם כמות 0</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">אצווה עם כמות 0</p>
                      <p className="text-sm text-gray-600">✅ מסומנת כ-consumed</p>
                      <p className="text-sm text-gray-600">✅ לא תופיע בספירה הבאה</p>
                      <p className="text-sm text-gray-600">✅ InventoryTransaction נוצר</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">שגיאה בטעינת נתונים חכמים</p>
                      <p className="text-sm text-gray-600">✅ יש fallback למצב רגיל</p>
                      <p className="text-sm text-gray-600">✅ הודעת שגיאה ידידותית</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">אין ריאגנטים מסוננים</p>
                      <p className="text-sm text-gray-600">✅ הודעה ברורה</p>
                      <p className="text-sm text-gray-600">✅ כפתור לניקוי פילטרים</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">אצווה חדשה מוספת ידנית</p>
                      <p className="text-sm text-gray-600">✅ נוצרת ReagentBatch חדשה</p>
                      <p className="text-sm text-gray-600">✅ InventoryTransaction נוצר</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Performance & Optimization */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Zap className="h-5 w-5 text-yellow-600" />
                  6. ביצועים ואופטימיזציה
                </h3>
                <div className="space-y-3 pr-6">
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Backend</p>
                      <p className="text-sm text-gray-600">✅ קריאה אחת לכל הנתונים</p>
                      <p className="text-sm text-gray-600">✅ שימוש ב-asServiceRole</p>
                      <p className="text-sm text-gray-600">✅ סינון ב-DB ולא ב-Frontend</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Frontend</p>
                      <p className="text-sm text-gray-600">✅ useMemo לחישובים כבדים</p>
                      <p className="text-sm text-gray-600">✅ useCallback לפונקציות</p>
                      <p className="text-sm text-gray-600">✅ Lazy loading</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Mobile Responsiveness */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Smartphone className="h-5 w-5 text-indigo-600" />
                  7. תמיכה במובייל
                </h3>
                <div className="space-y-3 pr-6">
                  
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">ספירה נוכחית</p>
                      <p className="text-sm text-gray-600">✅ כותרות מקוצרות</p>
                      <p className="text-sm text-gray-600">✅ כפתורים קומפקטיים</p>
                      <p className="text-sm text-gray-600">✅ Sheet צד לפילטרים</p>
                      <p className="text-sm text-gray-600">✅ Sticky bottom bar</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">היסטוריה</p>
                      <p className="text-sm text-gray-600">✅ Cards במקום טבלה</p>
                      <p className="text-sm text-gray-600">✅ Sheet לפילטרים</p>
                      <p className="text-sm text-gray-600">✅ פעולות מקוצרות</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Final Status */}
              <div className="border-t pt-6">
                <div className="bg-gradient-to-r from-green-50 to-emerald-50 border-2 border-green-200 rounded-xl p-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-green-100 p-3 rounded-full">
                      <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-green-900 mb-2">
                        ✅ מסך ספירת מלאי - מאושר לשימוש
                      </h3>
                      <p className="text-green-800 mb-3">
                        כל הבדיקות עברו בהצלחה! המסך מוכן לייצור.
                      </p>
                      <div className="grid grid-cols-2 gap-3 text-sm">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-green-700">Backend מוכן ✅</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-green-700">Frontend מוכן ✅</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-green-700">UI/UX מוכן ✅</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-green-700">Mobile מוכן ✅</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <Dialog open={showNoteDialog} onOpenChange={setShowNoteDialog}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle>{editingNote ? 'עריכת הערה' : 'הוספת הערה חדשה'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="note-title">כותרת</Label>
              <Input
                id="note-title"
                value={noteFormData.title}
                onChange={(e) => setNoteFormData({ ...noteFormData, title: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="note-content">תוכן</Label>
              <Textarea
                id="note-content"
                value={noteFormData.content}
                onChange={(e) => setNoteFormData({ ...noteFormData, content: e.target.value })}
                rows={8}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowNoteDialog(false)}>ביטול</Button>
            <Button onClick={handleSaveNote}>שמור</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
