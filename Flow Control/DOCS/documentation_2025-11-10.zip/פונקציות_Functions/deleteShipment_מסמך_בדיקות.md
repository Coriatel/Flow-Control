# מסמך בדיקות - למחיקת משלוח יוצא

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/deleteShipment.js

---

# מסמך בדיקות - deleteShipment

## T1: ביטול משלוח
**תוצאה**: ✅ כמויות הוחזרו

## T2: משלוח מאושר
**תוצאה**: ✅ שגיאה

## Checklist
- [ ] validation
- [ ] inventory restoration
- [ ] transactions
- [ ] soft delete