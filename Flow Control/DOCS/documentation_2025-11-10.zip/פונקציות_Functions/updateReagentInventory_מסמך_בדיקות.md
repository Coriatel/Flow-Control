# מסמך בדיקות - עדכון מלאי ריאגנט

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/updateReagentInventory.js

---

## בדיקות

1. **After Delivery**: verify totals updated
2. **After Withdrawal**: verify quantities decreased
3. **After Count**: verify corrections applied
4. **Edge Cases**: no batches, all expired, etc.