# מסמך בדיקות - יצירת דוחות

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/generateReports.js

---

## בדיקות

1. **Excel Export**: verify all columns
2. **PDF Export**: verify formatting
3. **Large Dataset**: 10,000+ rows
4. **Empty Dataset**: no data in range
5. **Special Characters**: Hebrew text in PDF