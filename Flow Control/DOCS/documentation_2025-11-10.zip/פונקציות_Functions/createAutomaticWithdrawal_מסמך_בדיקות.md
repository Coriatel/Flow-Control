# מסמך בדיקות - יצירת בקשת משיכה אוטומטית

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/createAutomaticWithdrawal.js

---

# מסמך בדיקות - createAutomaticWithdrawal

## T1: עם מסגרת פעילה
**תוצאה**: ✅ withdrawal created

## T2: ללא מסגרת
**תוצאה**: ✅ שגיאה

## T3: בדיקת יתרה
**תוצאה**: ✅ validation נכונה

## Checklist
- [ ] framework found
- [ ] withdrawal created
- [ ] items created
- [ ] validation