# מסמך בדיקות - ניהול ספקים - טעינת נתונים

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/getManageSuppliersData.js

---

# מסמך בדיקות - getManageSuppliersData

## T1: ספק עם ריאגנטים
**תוצאה**: ✅ reagents_count נכון

## T2: ספק ללא ריאגנטים
**תוצאה**: ✅ count = 0

## Checklist
- [ ] suppliers נטענים
- [ ] enrichment
- [ ] statistics