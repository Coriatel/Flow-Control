# מסמך בדיקות - בדיקת גישה ל-COA

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/testCOAAccess.js

---

## בדיקות

1. **Valid URL**: COA קיים
2. **Invalid URL**: 404
3. **Timeout**: server לא מגיב
4. **Wrong Type**: not PDF
5. **Batch Test**: 100 COAs