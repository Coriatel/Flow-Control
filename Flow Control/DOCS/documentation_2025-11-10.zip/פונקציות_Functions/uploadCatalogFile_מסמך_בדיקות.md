# מסמך בדיקות - ייבוא קטלוג מקובץ

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/uploadCatalogFile.js

---

## בדיקות

1. **Valid File**: כל השדות תקינים
2. **Duplicates**: קטלוג מספר קיים
3. **Invalid Supplier**: ספק לא מוכר
4. **Missing Required**: חסר catalog_number
5. **Large File**: 1000+ items