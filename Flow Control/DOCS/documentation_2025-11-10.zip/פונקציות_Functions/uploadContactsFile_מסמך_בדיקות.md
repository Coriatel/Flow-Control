# מסמך בדיקות - ייבוא אנשי קשר מקובץ

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/uploadContactsFile.js

---

## בדיקות

1. **Valid File**: כל השדות תקינים
2. **Missing Fields**: חלק מהשדות חסרים
3. **Invalid Supplier**: ספק שלא קיים
4. **Duplicates**: אותו איש קשר פעמיים
5. **Special Characters**: שמות בעברית, טלפונים עם מקפים