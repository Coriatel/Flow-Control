# מסמך בדיקות - ייצוא כל תעודות האנליזה

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/exportAllCoas.js

---

# מסמך בדיקות - exportAllCoas

## T1: ייצוא כל ה-COAs
**תוצאה**: ✅ ZIP עם כל הקבצים

## T2: סינון לפי שנה
**תוצאה**: ✅ רק 2024

## T3: מבנה תיקיות
**תוצאה**: ✅ supplier/reagent/file

## Checklist
- [ ] ZIP creation
- [ ] folder structure
- [ ] file naming
- [ ] download handling