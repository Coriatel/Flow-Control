# מסמך בדיקות - טעינת נתונים לקליטת משלוח

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/getNewDeliveryPageData.js

---

# מסמך בדיקות - getNewDeliveryPageData

## T1: הזמנות פתוחות
**תוצאה**: ✅ רק approved/partially_received

## T2: קיבוץ לפי ספק
**תוצאה**: ✅ reagents_by_supplier נכון

## T3: אצוות אחרונות
**תוצאה**: ✅ 100 אחרונות לאוטו-קומפליט

## Checklist
- [ ] orders enriched
- [ ] reagents grouped
- [ ] defaults set