# מסמך בדיקות - ריאגנטים לפי בית חולים

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/getReagentsForHospital.js

---

## בדיקות

1. **Isolation**: Hospital A can't see Hospital B data
2. **Admin**: can see all
3. **Batches**: filtered correctly