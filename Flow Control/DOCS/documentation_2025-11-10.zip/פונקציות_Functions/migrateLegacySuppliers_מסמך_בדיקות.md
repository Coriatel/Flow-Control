# מסמך בדיקות - העברת ספקים ישנים

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/migrateLegacySuppliers.js

---

## בדיקות

1. **Create Suppliers**: verify all created
2. **Update Reagents**: verify links updated
3. **Preserve Data**: no data loss
4. **Idempotent**: can run twice safely