# מסמך בדיקות - פרטי ספירה בודדת

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/getSingleInventoryCountDetails.js

---

# מסמך בדיקות - getSingleInventoryCountDetails

## T1: ספירה עם 50 פריטים
**תוצאה**: ✅ כל הפריטים מוצגים

## T2: ספירה עם הפרשים
**תוצאה**: ✅ delta מחושב נכון

## T3: ספירה לא קיימת
**תוצאה**: ✅ שגיאה 404

## Checklist
- [ ] טעינה
- [ ] enrichment
- [ ] delta calculation