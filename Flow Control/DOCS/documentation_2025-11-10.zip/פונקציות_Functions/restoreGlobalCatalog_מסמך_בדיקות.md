# מסמך בדיקות - שחזור קטלוג גלובלי

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/restoreGlobalCatalog.js

---

## בדיקות

1. **Valid Backup**: שחזור מלא
2. **Partial Restore**: חלק כבר קיים
3. **Invalid Data**: backup corrupted
4. **Large File**: 5000+ items