# מסמך בדיקות - הזמנות לפי בית חולים

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/getOrdersForHospital.js

---

## בדיקות

1. **Hospital A**: sees only Hospital A orders
2. **Hospital B**: sees only Hospital B orders
3. **Admin**: sees all orders
4. **No Hospital**: error handling