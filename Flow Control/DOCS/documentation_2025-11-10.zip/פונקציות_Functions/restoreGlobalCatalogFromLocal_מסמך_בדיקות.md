# מסמך בדיקות - שחזור קטלוג גלובלי מקטלוג מקומי

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/restoreGlobalCatalogFromLocal.js

---

## בדיקות

1. **Merge**: multiple labs → single global
2. **Deduplication**: same catalog_number
3. **Validation**: all required fields
4. **Report**: what was restored