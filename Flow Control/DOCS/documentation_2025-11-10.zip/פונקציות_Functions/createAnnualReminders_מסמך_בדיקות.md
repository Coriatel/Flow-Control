# מסמך בדיקות - יצירת תזכורות שנתיות

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/createAnnualReminders.js

---

## בדיקות

1. **Create**: verify reminders created
2. **Dates**: verify correct year
3. **Duplicates**: don't create twice
4. **Scheduled**: runs on Dec 31st