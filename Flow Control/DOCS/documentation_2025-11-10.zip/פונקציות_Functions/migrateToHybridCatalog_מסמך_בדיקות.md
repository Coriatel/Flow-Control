# מסמך בדיקות - מעבר למודל קטלוג היברידי

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/migrateToHybridCatalog.js

---

## בדיקות

1. **Migration**: all reagents migrated
2. **Links**: catalog_item_id set correctly
3. **Data Preservation**: no data loss
4. **Rollback**: can undo migration