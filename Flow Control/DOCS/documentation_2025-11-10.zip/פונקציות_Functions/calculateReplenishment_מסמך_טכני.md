# מסמך טכני - חישוב המלצות השלמה

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/calculateReplenishment.js

---

# מסמך טכני - calculateReplenishment

זהה ל-getReplenishmentData - מחזיר את אותן המלצות.

ההבדל: פונקציה זו נקראת on-demand (כפתור "חשב מחדש"), בעוד getReplenishmentData נקראת בטעינת הדף.