# מסמך בדיקות - ייבוא ספירת מלאי מקובץ

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/importInventoryCount.js

---

## בדיקות

1. **Valid File**: Excel עם כל העמודות
2. **Missing Columns**: קובץ חלקי
3. **Unknown Reagents**: שמות שלא קיימים
4. **Duplicate Batches**: אותו batch פעמיים
5. **Invalid Data**: quantity שלילית, תאריך לא תקין