# מסמך בדיקות - ייבוא קטלוג גלובלי למקומי

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/importGlobalCatalogToLocal.js

---

## בדיקות

1. **Single Import**: 1 item
2. **Bulk Import**: 50 items
3. **Duplicates**: item already exists
4. **Invalid ID**: global_id not found