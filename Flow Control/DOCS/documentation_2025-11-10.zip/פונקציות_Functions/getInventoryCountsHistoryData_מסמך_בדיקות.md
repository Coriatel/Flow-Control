# מסמך בדיקות - היסטוריית ספירות מלאי

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/getInventoryCountsHistoryData.js

---

# מסמך בדיקות - getInventoryCountsHistoryData

## T1: כל הספירות
**תוצאה**: ✅ כל הספירות נטעלות ממוינות

## T2: סינון לפי תאריך
**תוצאה**: ✅ רק ספירות בטווח

## T3: ספירה ללא entries
**תוצאה**: ✅ batches_count = 0

## Checklist
- [ ] טעינה
- [ ] מיון
- [ ] enrichment
- [ ] סינון