# מסמך בדיקות - מנהל ההתראות

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/alertsManager.js

---

## בדיקות

1. **Acknowledge**: verify status changed
2. **Resolve**: verify action_taken saved
3. **Snooze**: verify auto-reactivate after time
4. **Bulk**: 10 alerts at once
5. **Permissions**: only creator/admin can resolve