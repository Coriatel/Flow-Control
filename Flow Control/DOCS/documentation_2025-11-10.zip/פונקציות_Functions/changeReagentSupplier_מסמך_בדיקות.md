# מסמך בדיקות - שינוי ספק ריאגנט

**תאריך עדכון:** 10.11.2025
**גרסה:** 1.0
**נתיב:** functions/changeReagentSupplier.js

---

# מסמך בדיקות - changeReagentSupplier

## T1: שינוי ספק
**תוצאה**: ✅ היסטוריה נשמרת

## T2: ספק לא קיים
**תוצאה**: ✅ שגיאה

## Checklist
- [ ] history saved
- [ ] supplier updated
- [ ] dates tracked
- [ ] reason saved